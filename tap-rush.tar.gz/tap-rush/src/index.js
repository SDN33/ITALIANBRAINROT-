import React from 'react';
import ReactDOM from 'react-dom/client';
import TapRush from './TapRush';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <TapRush />
  </React.StrictMode>
);
