import { useState, useEffect, useRef, useCallback } from "react";

const TralalerloTralala = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    <ellipse cx="40" cy="38" rx="26" ry="18" fill="#4FC3F7" />
    <polygon points="40,12 52,30 28,30" fill="#0288D1" />
    <polygon points="14,32 3,22 3,46" fill="#0288D1" />
    <ellipse cx="44" cy="44" rx="16" ry="10" fill="#E1F5FE" />
    <circle cx="57" cy="30" r="5" fill="white" />
    <circle cx="58" cy="30" r="2.5" fill="#111" />
    <circle cx="57" cy="29" r="1" fill="white" />
    <path d="M52 42 Q58 48 65 42" stroke="#0288D1" strokeWidth="2.5" fill="none" />
    <polygon points="54,42 56,47 58,42" fill="white" />
    <polygon points="58,42 60,47 62,42" fill="white" />
    <rect x="27" y="52" width="7" height="14" rx="3.5" fill="#81D4FA" />
    <rect x="37" y="54" width="7" height="12" rx="3.5" fill="#81D4FA" />
    <rect x="47" y="52" width="7" height="14" rx="3.5" fill="#81D4FA" />
    <ellipse cx="30.5" cy="67" rx="9" ry="4" fill="#E53935" />
    <ellipse cx="40.5" cy="67" rx="9" ry="4" fill="#E53935" />
    <ellipse cx="50.5" cy="67" rx="9" ry="4" fill="#1565C0" />
    <path d="M25 66 Q31 63 36 67" stroke="white" strokeWidth="1.5" fill="none" />
    <path d="M35 66 Q41 63 46 67" stroke="white" strokeWidth="1.5" fill="none" />
    <path d="M45 65 Q51 62 56 66" stroke="white" strokeWidth="1.5" fill="none" />
  </svg>
);

const BombardioCrocodilo = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    <ellipse cx="38" cy="44" rx="30" ry="13" fill="#66BB6A" />
    <ellipse cx="64" cy="43" rx="14" ry="10" fill="#4CAF50" />
    <path d="M50 48 Q64 56 78 48" fill="#2E7D32" />
    {[54,59,64,69].map(x => (
      <polygon key={x} points={`${x},48 ${x+2},53 ${x+4},48`} fill="white" />
    ))}
    <circle cx="67" cy="36" r="5" fill="#FFEB3B" />
    <circle cx="68" cy="36" r="2.5" fill="#111" />
    <circle cx="67.5" cy="35" r="1" fill="white" />
    <polygon points="34,44 12,22 8,44" fill="#81C784" />
    <polygon points="34,46 12,64 8,46" fill="#A5D6A7" />
    <polygon points="20,44 6,36 4,44" fill="#C8E6C9" />
    <circle cx="10" cy="44" r="3" fill="#424242" />
    <line x1="10" y1="33" x2="10" y2="55" stroke="#757575" strokeWidth="3.5" strokeLinecap="round" />
    <line x1="2" y1="44" x2="18" y2="44" stroke="#757575" strokeWidth="3.5" strokeLinecap="round" />
    <ellipse cx="30" cy="56" rx="5" ry="3" fill="#424242" />
    <ellipse cx="42" cy="58" rx="5" ry="3" fill="#424242" />
    <text x="36" y="47" fontSize="7" fill="#1B5E20" fontWeight="bold">✈</text>
  </svg>
);

const ChimpanziniBananini = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    <path d="M24 68 Q18 44 34 20 Q50 4 62 18 Q68 32 56 52 Q44 70 28 72 Z" fill="#FFD54F" />
    <path d="M27 66 Q22 44 36 24 Q50 8 60 20" stroke="#F57F17" strokeWidth="3" fill="none" />
    <path d="M28 70 Q25 52 34 26" stroke="#FFF176" strokeWidth="2" fill="none" opacity="0.5" />
    <circle cx="50" cy="26" r="15" fill="#8D6E63" />
    <ellipse cx="50" cy="31" rx="9" ry="7" fill="#BCAAA4" />
    <circle cx="44" cy="22" r="4.5" fill="white" />
    <circle cx="56" cy="22" r="4.5" fill="white" />
    <circle cx="45" cy="22" r="2.5" fill="#111" />
    <circle cx="57" cy="22" r="2.5" fill="#111" />
    <circle cx="45" cy="21" r="1" fill="white" />
    <circle cx="57" cy="21" r="1" fill="white" />
    <line x1="41" y1="17" x2="48" y2="19" stroke="#4E342E" strokeWidth="2.5" />
    <line x1="52" y1="19" x2="59" y2="17" stroke="#4E342E" strokeWidth="2.5" />
    <ellipse cx="50" cy="28" rx="4" ry="3" fill="#A1887F" />
    <circle cx="48.5" cy="28" r="1.5" fill="#6D4C41" />
    <circle cx="51.5" cy="28" r="1.5" fill="#6D4C41" />
    <path d="M43 34 Q50 40 57 34" stroke="#4E342E" strokeWidth="2" fill="none" />
    <circle cx="34" cy="24" r="7" fill="#8D6E63" />
    <circle cx="34" cy="24" r="4.5" fill="#BCAAA4" />
    <circle cx="66" cy="24" r="7" fill="#8D6E63" />
    <circle cx="66" cy="24" r="4.5" fill="#BCAAA4" />
    <path d="M37 36 Q26 44 28 52" stroke="#8D6E63" strokeWidth="5" fill="none" strokeLinecap="round" />
    <path d="M63 36 Q72 44 70 52" stroke="#8D6E63" strokeWidth="5" fill="none" strokeLinecap="round" />
  </svg>
);

const TungTungSahur = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    <rect x="24" y="18" width="32" height="48" rx="10" fill="#795548" />
    <ellipse cx="40" cy="18" rx="16" ry="6" fill="#A1887F" />
    <ellipse cx="40" cy="66" rx="16" ry="6" fill="#5D4037" />
    {[24,34,44,54].map((y,i) => (
      <line key={i} x1="28" y1={y} x2="52" y2={y} stroke="#5D4037" strokeWidth="1.5" opacity="0.7" />
    ))}
    <circle cx="33" cy="38" r="8" fill="white" />
    <circle cx="47" cy="38" r="8" fill="white" />
    <circle cx="34" cy="39" r="5" fill="#B71C1C" />
    <circle cx="48" cy="39" r="5" fill="#B71C1C" />
    <circle cx="33" cy="38" r="2.5" fill="#111" />
    <circle cx="47" cy="38" r="2.5" fill="#111" />
    <circle cx="32.5" cy="37" r="1" fill="white" />
    <circle cx="46.5" cy="37" r="1" fill="white" />
    <path d="M31 53 Q40 49 49 53" stroke="#3E2723" strokeWidth="3" fill="none" />
    {[35,40,45].map(x => (
      <line key={x} x1={x} y1="51" x2={x} y2="55" stroke="#3E2723" strokeWidth="2" />
    ))}
    <line x1="56" y1="28" x2="74" y2="14" stroke="#6D4C41" strokeWidth="6" strokeLinecap="round" />
    <ellipse cx="76" cy="12" rx="8" ry="5" fill="#8D6E63" transform="rotate(-30 76 12)" />
    <ellipse cx="76" cy="12" rx="5" ry="3" fill="#A1887F" transform="rotate(-30 76 12)" />
  </svg>
);

const LiriliLarila = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    <rect x="30" y="24" width="20" height="34" rx="10" fill="#43A047" />
    <rect x="12" y="30" width="18" height="10" rx="5" fill="#43A047" />
    <rect x="12" y="22" width="10" height="18" rx="5" fill="#43A047" />
    <rect x="50" y="28" width="18" height="10" rx="5" fill="#43A047" />
    <rect x="58" y="20" width="10" height="18" rx="5" fill="#43A047" />
    {[[36,28],[44,28],[32,38],[48,38],[36,48],[44,48]].map(([x,y],i) => (
      <line key={i} x1={x} y1={y} x2={x} y2={y-7} stroke="#1B5E20" strokeWidth="2" strokeLinecap="round" />
    ))}
    {[[15,28],[19,22],[54,26],[60,20]].map(([x,y],i) => (
      <line key={i} x1={x} y1={y} x2={x} y2={y-6} stroke="#1B5E20" strokeWidth="2" strokeLinecap="round" />
    ))}
    <ellipse cx="40" cy="24" rx="17" ry="14" fill="#9E9E9E" />
    <ellipse cx="23" cy="20" rx="9" ry="13" fill="#BDBDBD" />
    <ellipse cx="23" cy="20" rx="5.5" ry="8.5" fill="#EF9A9A" />
    <ellipse cx="57" cy="20" rx="9" ry="13" fill="#BDBDBD" />
    <ellipse cx="57" cy="20" rx="5.5" ry="8.5" fill="#EF9A9A" />
    <path d="M40 34 Q37 44 43 50 Q41 54 36 52" stroke="#9E9E9E" strokeWidth="7" fill="none" strokeLinecap="round" />
    <circle cx="33" cy="16" r="4.5" fill="white" />
    <circle cx="47" cy="16" r="4.5" fill="white" />
    <circle cx="34" cy="16" r="2.5" fill="#333" />
    <circle cx="48" cy="16" r="2.5" fill="#333" />
    <circle cx="33.5" cy="15" r="1" fill="white" />
    <circle cx="47.5" cy="15" r="1" fill="white" />
    <path d="M34 28 Q29 35 33 40" stroke="#FFF9C4" strokeWidth="3.5" fill="none" strokeLinecap="round" />
    <path d="M46 28 Q51 35 47 40" stroke="#FFF9C4" strokeWidth="3.5" fill="none" strokeLinecap="round" />
    <ellipse cx="34" cy="64" rx="10" ry="4.5" fill="#FF8F00" />
    <ellipse cx="46" cy="65" rx="10" ry="4.5" fill="#FF8F00" />
    <line x1="27" y1="61" x2="41" y2="61" stroke="#E65100" strokeWidth="2.5" />
    <line x1="39" y1="62" x2="53" y2="62" stroke="#E65100" strokeWidth="2.5" />
  </svg>
);

const BallerinaCappuccina = () => (
  <svg viewBox="0 0 80 80" width="100%" height="100%">
    {[18,24,30,36,42,48,54,60,62].map((x, i) => (
      <ellipse key={i} cx={x} cy={56} rx="5" ry="7" fill={i % 2 === 0 ? "#F8BBD9" : "#F48FB1"} />
    ))}
    <ellipse cx="40" cy="54" rx="20" ry="9" fill="#EC407A" opacity="0.5" />
    <rect x="33" y="38" width="14" height="17" rx="5" fill="#CE93D8" />
    <path d="M33 44 Q20 36 16 28" stroke="#BA68C8" strokeWidth="6" fill="none" strokeLinecap="round" />
    <circle cx="14" cy="26" r="5" fill="#CE93D8" />
    <path d="M47 44 Q60 36 64 28" stroke="#BA68C8" strokeWidth="6" fill="none" strokeLinecap="round" />
    <circle cx="66" cy="26" r="5" fill="#CE93D8" />
    <rect x="26" y="16" width="28" height="22" rx="5" fill="#EFEBE9" />
    <path d="M53 20 Q62 25 53 33" stroke="#A1887F" strokeWidth="3.5" fill="none" />
    <ellipse cx="40" cy="18" rx="13" ry="5" fill="#6D4C41" />
    <ellipse cx="40" cy="20" rx="11" ry="4" fill="#4E342E" />
    <circle cx="38" cy="23" r="3.5" fill="white" opacity="0.6" />
    <ellipse cx="40" cy="16" rx="16" ry="4" fill="#D7CCC8" />
    <circle cx="33" cy="29" r="3" fill="#4E342E" />
    <circle cx="47" cy="29" r="3" fill="#4E342E" />
    <circle cx="33.5" cy="28" r="1.2" fill="white" />
    <circle cx="47.5" cy="28" r="1.2" fill="white" />
    <path d="M34 34 Q40 38 46 34" stroke="#4E342E" strokeWidth="2" fill="none" />
    <line x1="36" y1="63" x2="30" y2="76" stroke="#CE93D8" strokeWidth="5" strokeLinecap="round" />
    <line x1="44" y1="63" x2="52" y2="76" stroke="#CE93D8" strokeWidth="5" strokeLinecap="round" />
    <ellipse cx="28" cy="77" rx="7" ry="3.5" fill="#F48FB1" />
    <ellipse cx="54" cy="77" rx="7" ry="3.5" fill="#F48FB1" />
  </svg>
);

const BRAINROTS = [
  { id: 0, name: "TRALALERO", subtitle: "Tralala", Component: TralalerloTralala, bg: "#0277BD", glow: "#4FC3F7", dark: "#01579B" },
  { id: 1, name: "BOMBARDIRO", subtitle: "Crocodilo", Component: BombardioCrocodilo, bg: "#2E7D32", glow: "#81C784", dark: "#1B5E20" },
  { id: 2, name: "CHIMPANZINI", subtitle: "Bananini", Component: ChimpanziniBananini, bg: "#E65100", glow: "#FFD54F", dark: "#BF360C" },
  { id: 3, name: "TUNG TUNG", subtitle: "Tung Sahur", Component: TungTungSahur, bg: "#4E342E", glow: "#BCAAA4", dark: "#3E2723" },
  { id: 4, name: "LIRILI", subtitle: "Larila", Component: LiriliLarila, bg: "#1B5E20", glow: "#A5D6A7", dark: "#003300" },
  { id: 5, name: "BALLERINA", subtitle: "Cappuccina", Component: BallerinaCappuccina, bg: "#880E4F", glow: "#F48FB1", dark: "#560027" },
];

const GRID_SIZE = 9;
const INITIAL_TIME = 4.0;
const MIN_TIME = 0.9;
const TIME_DECAY = 0.06;

function rnd(exclude = null) {
  let i; do { i = Math.floor(Math.random() * BRAINROTS.length); } while (i === exclude); return i;
}
function makeGrid(t) {
  const g = Array(GRID_SIZE).fill(null).map(() => Math.random() < 0.35 ? t : rnd(t));
  if (!g.includes(t)) g[Math.floor(Math.random() * GRID_SIZE)] = t;
  return g;
}

function TimerBar({ progress, glow }) {
  const color = progress > 0.5 ? glow : progress > 0.25 ? "#FF9500" : "#FF3B5C";
  return (
    <div style={{ width: "100%", height: 10, background: "rgba(255,255,255,0.08)", borderRadius: 5, overflow: "hidden" }}>
      <div style={{ height: "100%", width: `${progress * 100}%`, background: color, boxShadow: `0 0 12px ${color}`, borderRadius: 5, transition: "width 0.05s linear, background 0.3s" }} />
    </div>
  );
}

function TileCell({ idx, targetIdx, onClick }) {
  const br = BRAINROTS[idx];
  const C = br.Component;
  const [pressed, setPressed] = useState(false);
  const tap = (e) => { setPressed(true); setTimeout(() => setPressed(false), 120); onClick(e, idx === targetIdx); };
  return (
    <div onClick={tap} style={{
      width: "100%", aspectRatio: "1", borderRadius: 14,
      background: `radial-gradient(circle at 40% 30%, ${br.glow}28, ${br.bg}55)`,
      border: `2px solid ${br.glow}66`,
      boxShadow: pressed ? `0 0 24px ${br.glow}99` : `0 0 8px ${br.glow}22`,
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 5, cursor: "pointer",
      transform: pressed ? "scale(0.82)" : "scale(1)",
      transition: "transform 0.1s, box-shadow 0.1s",
      userSelect: "none", WebkitUserSelect: "none", overflow: "hidden",
    }}>
      <C />
    </div>
  );
}

export default function TapRush() {
  const [phase, setPhase] = useState("menu");
  const [score, setScore] = useState(0);
  const [best, setBest] = useState(0);
  const [targetIdx, setTargetIdx] = useState(0);
  const [grid, setGrid] = useState([]);
  const [timeLeft, setTimeLeft] = useState(INITIAL_TIME);
  const [maxTime, setMaxTime] = useState(INITIAL_TIME);
  const [combo, setCombo] = useState(0);
  const [shake, setShake] = useState(false);
  const [flash, setFlash] = useState(null);
  const timerRef = useRef(null);
  const scoreRef = useRef(0);
  const comboRef = useRef(0);
  const maxTimeRef = useRef(INITIAL_TIME);
  const targetRef = useRef(0);

  const endGame = useCallback(() => {
    clearInterval(timerRef.current);
    setBest(prev => Math.max(prev, scoreRef.current));
    setPhase("dead");
  }, []);

  const nextRound = useCallback((newT) => {
    setGrid(makeGrid(newT));
    const nm = Math.max(MIN_TIME, maxTimeRef.current - TIME_DECAY);
    maxTimeRef.current = nm;
    setMaxTime(nm);
    setTimeLeft(nm);
  }, []);

  useEffect(() => {
    if (phase !== "playing") return;
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setTimeLeft(t => {
        if (t <= 0.05) { clearInterval(timerRef.current); setShake(true); setTimeout(() => { setShake(false); endGame(); }, 400); return 0; }
        return t - 0.05;
      });
    }, 50);
    return () => clearInterval(timerRef.current);
  }, [phase, grid, endGame]);

  const handleTap = useCallback((e, correct) => {
    if (correct) {
      const ns = scoreRef.current + 1 + Math.floor(comboRef.current / 3);
      scoreRef.current = ns; comboRef.current += 1;
      setScore(ns); setCombo(comboRef.current);
      setFlash(BRAINROTS[targetRef.current].glow);
      setTimeout(() => setFlash(null), 140);
      const nt = rnd(targetRef.current);
      targetRef.current = nt; setTargetIdx(nt); nextRound(nt);
    } else {
      comboRef.current = 0; setCombo(0);
      setShake(true); setTimeout(() => setShake(false), 350);
      setTimeLeft(t => Math.max(0, t - 0.7));
    }
  }, [nextRound]);

  const start = () => {
    scoreRef.current = 0; comboRef.current = 0; maxTimeRef.current = INITIAL_TIME;
    setScore(0); setCombo(0); setMaxTime(INITIAL_TIME); setTimeLeft(INITIAL_TIME);
    const t = rnd(); targetRef.current = t; setTargetIdx(t); setGrid(makeGrid(t));
    setPhase("playing");
  };

  const target = BRAINROTS[targetIdx];
  const TC = target.Component;

  return (
    <div style={{ minHeight: "100vh", background: "#07090E", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Bangers', cursive", letterSpacing: 1, overflow: "hidden", position: "relative" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Bangers&family=Nunito:wght@700;900&display=swap');
        @keyframes shake { 0%,100%{transform:translateX(0)} 20%{transform:translateX(-10px) rotate(-1.5deg)} 40%{transform:translateX(10px) rotate(1.5deg)} 60%{transform:translateX(-6px)} 80%{transform:translateX(6px)} }
        @keyframes fadeUp { from{opacity:0;transform:translateY(20px)} to{opacity:1;transform:translateY(0)} }
        @keyframes popIn { 0%{transform:scale(0.3) rotate(-10deg);opacity:0} 70%{transform:scale(1.12) rotate(3deg)} 100%{transform:scale(1) rotate(0);opacity:1} }
        @keyframes wobble { 0%,100%{transform:rotate(-4deg) scale(1)} 50%{transform:rotate(4deg) scale(1.05)} }
        @keyframes comboSplash { 0%{transform:scale(0.4);opacity:0} 60%{transform:scale(1.15)} 100%{transform:scale(1);opacity:1} }
        @keyframes pulse { 0%,100%{box-shadow:0 0 20px #4FC3F755} 50%{box-shadow:0 0 40px #4FC3F7bb} }
      `}</style>

      <div style={{ position: "fixed", inset: 0, pointerEvents: "none", background: phase === "playing" ? `radial-gradient(ellipse at 50% 50%, ${target.glow}18 0%, transparent 65%)` : "radial-gradient(ellipse at 25% 25%, #4FC3F718, transparent 50%), radial-gradient(ellipse at 75% 75%, #F48FB118, transparent 50%)", transition: "background 0.4s" }} />
      {flash && <div style={{ position: "fixed", inset: 0, background: flash, opacity: 0.12, pointerEvents: "none", zIndex: 50 }} />}

      <div style={{ width: "min(430px, 100vw)", padding: "0 14px", animation: shake ? "shake 0.35s ease-out" : "none", zIndex: 10 }}>

        {/* MENU */}
        {phase === "menu" && (
          <div style={{ textAlign: "center", animation: "fadeUp 0.5s ease-out" }}>
            <div style={{ display: "flex", justifyContent: "center", gap: 8, marginBottom: 10 }}>
              {BRAINROTS.map((br, i) => {
                const C = br.Component;
                return (
                  <div key={br.id} style={{ width: 52, height: 52, background: `radial-gradient(circle, ${br.glow}33, ${br.bg}22)`, border: `2px solid ${br.glow}66`, borderRadius: 14, padding: 5, animation: `wobble ${1.4 + i * 0.2}s ease-in-out infinite` }}>
                    <C />
                  </div>
                );
              })}
            </div>
            <h1 style={{ fontSize: 56, margin: "0 0 2px", background: "linear-gradient(135deg, #4FC3F7, #81C784, #FFD54F, #F48FB1)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", lineHeight: 1 }}>TAP RUSH</h1>
            <div style={{ fontSize: 13, fontFamily: "'Nunito', sans-serif", fontWeight: 900, color: "#ffffff55", letterSpacing: 5, marginBottom: 22 }}>BRAINROT EDITION</div>

            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 18, padding: "16px 18px", marginBottom: 20 }}>
              <p style={{ color: "#ffffffaa", fontSize: 13, fontFamily: "'Nunito', sans-serif", fontWeight: 700, lineHeight: 1.8, margin: 0 }}>
                Tape uniquement le bon personnage !<br />
                <span style={{ color: "#FF5722" }}>❌ Erreur = -0.7 sec</span> &nbsp;|&nbsp; <span style={{ color: "#FFD54F" }}>🔥 Combo = bonus</span>
              </p>
            </div>

            {best > 0 && (
              <div style={{ marginBottom: 18 }}>
                <div style={{ color: "#ffffff44", fontSize: 11, fontFamily: "'Nunito', sans-serif", fontWeight: 700, letterSpacing: 4 }}>🏆 RECORD</div>
                <div style={{ fontSize: 48, color: "#FFD54F", textShadow: "0 0 20px #FFD54F88" }}>{best}</div>
              </div>
            )}

            <button onClick={start} style={{ width: "100%", padding: "17px", fontSize: 28, fontFamily: "inherit", letterSpacing: 4, background: "linear-gradient(135deg, #0277BD, #2E7D32)", border: "none", borderRadius: 18, color: "#fff", cursor: "pointer", textShadow: "0 2px 4px rgba(0,0,0,0.4)", animation: "pulse 2s infinite" }}>
              JOUER ! 🕹️
            </button>
          </div>
        )}

        {/* PLAYING */}
        {phase === "playing" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
              <div>
                <div style={{ color: "#ffffff44", fontSize: 10, fontFamily: "'Nunito', sans-serif", fontWeight: 700, letterSpacing: 3 }}>SCORE</div>
                <div style={{ fontSize: 42, color: "#fff", lineHeight: 1 }}>{score}</div>
              </div>
              {combo >= 3 && (
                <div style={{ background: `${target.bg}44`, border: `2px solid ${target.glow}99`, borderRadius: 14, padding: "5px 14px", textAlign: "center", animation: "comboSplash 0.25s ease-out" }}>
                  <div style={{ color: target.glow, fontSize: 10, fontFamily: "'Nunito', sans-serif", fontWeight: 900 }}>COMBO</div>
                  <div style={{ color: target.glow, fontSize: 30, textShadow: `0 0 12px ${target.glow}` }}>x{combo}</div>
                </div>
              )}
              <div style={{ textAlign: "right" }}>
                <div style={{ color: "#ffffff44", fontSize: 10, fontFamily: "'Nunito', sans-serif", fontWeight: 700, letterSpacing: 3 }}>🏆 BEST</div>
                <div style={{ fontSize: 28, color: "#ffffff55" }}>{Math.max(best, score)}</div>
              </div>
            </div>

            <div style={{ marginBottom: 14 }}>
              <TimerBar progress={timeLeft / maxTime} glow={target.glow} />
            </div>

            {/* Target */}
            <div style={{ background: `linear-gradient(135deg, ${target.bg}33, ${target.dark}55)`, border: `2px solid ${target.glow}77`, borderRadius: 18, padding: "10px 14px", marginBottom: 14, display: "flex", alignItems: "center", gap: 12, boxShadow: `0 0 18px ${target.glow}22` }}>
              <div style={{ width: 62, height: 62, flexShrink: 0, background: `radial-gradient(circle, ${target.glow}33, transparent)`, borderRadius: 14, padding: 4, animation: "popIn 0.3s ease-out" }}>
                <TC />
              </div>
              <div>
                <div style={{ color: "#ffffff55", fontSize: 10, fontFamily: "'Nunito', sans-serif", fontWeight: 700, letterSpacing: 4 }}>TAPE UNIQUEMENT</div>
                <div style={{ color: target.glow, fontSize: 26, textShadow: `0 0 10px ${target.glow}` }}>{target.name}</div>
                <div style={{ color: "#ffffff66", fontSize: 12, fontFamily: "'Nunito', sans-serif", fontWeight: 700 }}>{target.subtitle}</div>
              </div>
            </div>

            {/* Grid 3x3 */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 10 }}>
              {grid.map((bIdx, i) => (
                <TileCell key={i} idx={bIdx} targetIdx={targetIdx} onClick={(e, c) => handleTap(e, c)} />
              ))}
            </div>
          </div>
        )}

        {/* DEAD */}
        {phase === "dead" && (
          <div style={{ textAlign: "center", animation: "fadeUp 0.4s ease-out" }}>
            <div style={{ fontSize: 72, marginBottom: 6, animation: "popIn 0.4s ease-out" }}>💀</div>
            <h2 style={{ fontSize: 50, margin: "0 0 24px", color: "#FF3B5C", textShadow: "0 0 30px #FF3B5C, 0 0 60px #FF3B5C44" }}>GAME OVER</h2>

            <div style={{ display: "flex", justifyContent: "center", flexWrap: "wrap", gap: 6, marginBottom: 18 }}>
              {BRAINROTS.map(br => { const C = br.Component; return (
                <div key={br.id} style={{ width: 50, height: 50, background: `${br.bg}33`, border: `1px solid ${br.glow}55`, borderRadius: 12, padding: 5 }}>
                  <C />
                </div>
              ); })}
            </div>

            <div style={{ background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 22, padding: "22px", marginBottom: 22 }}>
              <div style={{ color: "#ffffff44", fontSize: 12, fontFamily: "'Nunito', sans-serif", fontWeight: 700, letterSpacing: 4 }}>TON SCORE</div>
              <div style={{ fontSize: 78, color: "#fff", lineHeight: 1.1 }}>{score}</div>
              {score >= best && score > 0 && <div style={{ color: "#FFD54F", fontSize: 18, textShadow: "0 0 15px #FFD54F", animation: "popIn 0.4s ease-out 0.2s both" }}>🏆 NOUVEAU RECORD !</div>}
              {score < best && <div style={{ color: "#ffffff44", fontSize: 14, fontFamily: "'Nunito', sans-serif", fontWeight: 700 }}>Record : {best}</div>}
            </div>

            <button onClick={start} style={{ width: "100%", padding: "17px", fontSize: 28, fontFamily: "inherit", letterSpacing: 4, background: "linear-gradient(135deg, #FF3B5C, #FF9500)", border: "none", borderRadius: 18, color: "#fff", cursor: "pointer", boxShadow: "0 0 30px #FF3B5C66", marginBottom: 12, textShadow: "0 2px 4px rgba(0,0,0,0.4)" }}>
              REJOUER ⚡
            </button>
            <button onClick={() => setPhase("menu")} style={{ width: "100%", padding: "13px", fontSize: 18, fontFamily: "inherit", letterSpacing: 3, background: "transparent", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 18, color: "#ffffff55", cursor: "pointer" }}>
              MENU
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
