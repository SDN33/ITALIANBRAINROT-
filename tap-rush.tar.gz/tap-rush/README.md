# 🦈 Tap Rush — Brainrot Edition

Un jeu mobile hyper-casual de réflexes construit avec React.  
Tape les bons personnages **Italian Brainrot** avant que le timer expire !

## 🎮 Personnages

| Perso | Description |
|---|---|
| **Tralalero Tralala** | Requin à 3 pattes avec Nike |
| **Bombardiro Crocodilo** | Croco-avion bombardier |
| **Chimpanzini Bananini** | Singe avec corps de banane |
| **Tung Tung Tung Sahur** | Bûche terrifiante avec batte |
| **Lirili Larila** | Éléphant-cactus en sandales |
| **Ballerina Cappuccina** | Ballerine avec tête de café |

## 🚀 Lancer le projet

```bash
# Installer les dépendances
npm install

# Lancer en développement
npm start

# Build production
npm run build
```

## 📱 Stack technique

- **React 18** — UI
- **SVG inline** — Illustrations des personnages (aucune image externe)
- **CSS animations** — Effets visuels (shake, popIn, wobble…)
- **localStorage** — Sauvegarde du meilleur score

## 🎯 Règles du jeu

1. Une cible s'affiche en haut (ex: **TRALALERO**)
2. Tape uniquement les cases correspondantes dans la grille 3×3
3. ❌ Chaque erreur = **-0.7 secondes**
4. ⚡ Le timer accélère à chaque bonne réponse
5. 🔥 Enchaîne des combos (x3+) pour gagner plus de points

## 🗂️ Structure

```
tap-rush/
├── public/
│   └── index.html
├── src/
│   ├── index.js       # Entry point React
│   └── TapRush.jsx    # Jeu complet (composants + logique + SVG)
├── .gitignore
├── package.json
└── README.md
```

## 📲 React Native

Pour porter sur mobile natif, remplace :
- `div` → `View` / `Text`
- `onClick` → `onPress`
- Animations → `react-native-reanimated`
- `localStorage` → `AsyncStorage`

---

Made with ❤️ and 🧠rot
